<!-- Name:Seifeldin Eid
    Date: Feb 19
    Section: CST 8285 section 303
    Lab: assignment 2
    File: CSS for web development
    assignment objective:This assignment is about creating, editing , viewing and deleting
    a entity that were created/presented in a mysql db table
    using CRUD Operations. -->

<?php
    //Used to throw mysqli_sql_exceptions for database errors 
    // instead of a normal PHP warning
   // mysqli_report(MYSQLI_REPORT_STRICT);
    
    /* Database credentials. Assuming you are running MySQL
    server with default setting (user 'root' with no password) 
    or use appuser
    */
   // define('DB_SERVER', 'localhost');
   // define('DB_USERNAME', 'appuser'); 
   // define('DB_PASSWORD', 'password');
   // define('DB_NAME', 'demo');
     
    /* Attempt to connect to MySQL database */
   // try{
    //    $mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
   //     }
  //  catch(mysqli_sql_exception $e){
    //    throw $e;
    //    }

?>